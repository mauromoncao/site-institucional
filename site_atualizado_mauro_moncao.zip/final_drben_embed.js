/**
 * Dr. Ben - Assistente Jurídico Virtual
 * Script de Integração para o Site Oficial mauromoncao.adv.br
 * 
 * Funcionalidades:
 * 1. Injeta aba "Dr. Ben IA" no menu de navegação do site (desktop e mobile)
 * 2. Cria widget flutuante (FAB) com foto do Dr. Ben
 * 3. Abre chat em modal responsivo OU navega para landing page
 * 
 * Compatível com:
 * - Sites com menu UL/LI (versão Hostinger)
 * - Sites com menu DIV/A (versão Manus Space / www)
 * 
 * Como usar:
 *   <script src="https://SEU_DOMINIO_DRBEN/drben-embed.js"></script>
 */
(function() {
  'use strict';

  // ── Config ──────────────────────────────────────────────
  var scripts = document.getElementsByTagName('script');
  var baseUrl = '';
  for (var i = 0; i < scripts.length; i++) {
    if (scripts[i].src && scripts[i].src.indexOf('drben-embed.js') !== -1) {
      baseUrl = 'https://drbenlaw-tdanyk37.manus.space';
      break;
    }
  }
  var config = window.DrBenConfig || {};
  var position = config.position || 'right';
  var embedUrl = baseUrl + '/embed';
  var landingUrl = baseUrl + '/';
  var drBenPhoto = 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663241140579/iTbPVnLXshtjVQBj.jpeg';

  // ── Styles ──────────────────────────────────────────────
  var css = document.createElement('style');
  css.textContent = '\n' +
    '/* ── Dr. Ben Nav Item ── */\n' +
    '.drben-nav-item {\n' +
    '  display: inline-flex !important;\n' +
    '  align-items: center !important;\n' +
    '  gap: 6px !important;\n' +
    '  cursor: pointer !important;\n' +
    '  position: relative !important;\n' +
    '  font-weight: 600 !important;\n' +
    '  transition: all 0.3s ease !important;\n' +
    '  text-decoration: none !important;\n' +
    '}\n' +
    '.drben-nav-item .drben-nav-avatar {\n' +
    '  width: 28px !important;\n' +
    '  height: 28px !important;\n' +
    '  border-radius: 50% !important;\n' +
    '  border: 2px solid #dec078 !important;\n' +
    '  object-fit: cover !important;\n' +
    '  transition: transform 0.3s ease !important;\n' +
    '}\n' +
    '.drben-nav-item:hover .drben-nav-avatar {\n' +
    '  transform: scale(1.1) !important;\n' +
    '}\n' +
    '.drben-nav-text {\n' +
    '  color: #dec078 !important;\n' +
    '  text-shadow: none !important;\n' +
    '  font-weight: 700 !important;\n' +
    '}\n' +
    '.drben-nav-underline {\n' +
    '  position: absolute !important;\n' +
    '  bottom: -8px !important;\n' +
    '  left: 0 !important;\n' +
    '  width: 100% !important;\n' +
    '  height: 2px !important;\n' +
    '  background: #dec078 !important;\n' +
    '  opacity: 0 !important;\n' +
    '  transition: opacity 0.3s !important;\n' +
    '}\n' +
    '.drben-nav-item:hover .drben-nav-underline {\n' +
    '  opacity: 1 !important;\n' +
    '}\n' +
    '.drben-nav-badge {\n' +
    '  background: #dec078 !important;\n' +
    '  color: #19385c !important;\n' +
    '  font-size: 9px !important;\n' +
    '  font-weight: 800 !important;\n' +
    '  padding: 1px 5px !important;\n' +
    '  border-radius: 8px !important;\n' +
    '  letter-spacing: 0.5px !important;\n' +
    '  line-height: 1.4 !important;\n' +
    '  text-transform: uppercase !important;\n' +
    '  animation: drben-badge-pulse 2s ease-in-out infinite !important;\n' +
    '}\n' +
    '@keyframes drben-badge-pulse {\n' +
    '  0%, 100% { opacity: 1; }\n' +
    '  50% { opacity: 0.6; }\n' +
    '}\n' +
    '\n' +
    '/* ── Mobile Nav Item ── */\n' +
    '.drben-mobile-nav {\n' +
    '  display: flex !important;\n' +
    '  align-items: center !important;\n' +
    '  gap: 10px !important;\n' +
    '  padding: 8px 0 !important;\n' +
    '  cursor: pointer !important;\n' +
    '  font-weight: 300 !important;\n' +
    '  font-size: 16px !important;\n' +
    '  text-decoration: none !important;\n' +
    '  background: none !important;\n' +
    '  border: none !important;\n' +
    '  transition: all 0.3s !important;\n' +
    '}\n' +
    '.drben-mobile-nav .drben-nav-avatar {\n' +
    '  width: 24px !important;\n' +
    '  height: 24px !important;\n' +
    '  border-radius: 50% !important;\n' +
    '  border: 2px solid #dec078 !important;\n' +
    '  object-fit: cover !important;\n' +
    '}\n' +
    '.drben-mobile-nav .drben-nav-badge {\n' +
    '  font-size: 8px !important;\n' +
    '}\n' +
    '\n' +
    '/* ── FAB (Floating Action Button) ── */\n' +
    '.drben-fab {\n' +
    '  position: fixed !important;\n' +
    '  bottom: 24px !important;\n' +
    '  ' + position + ': 24px !important;\n' +
    '  z-index: 99999 !important;\n' +
    '  width: 64px !important;\n' +
    '  height: 64px !important;\n' +
    '  border-radius: 50% !important;\n' +
    '  background: linear-gradient(135deg, #19385c 0%, #1e4470 100%) !important;\n' +
    '  border: 3px solid #dec078 !important;\n' +
    '  cursor: pointer !important;\n' +
    '  box-shadow: 0 4px 20px rgba(25,56,92,0.4), 0 0 0 0 rgba(222,192,120,0.4) !important;\n' +
    '  transition: all 0.3s ease !important;\n' +
    '  display: flex !important;\n' +
    '  align-items: center !important;\n' +
    '  justify-content: center !important;\n' +
    '  overflow: hidden !important;\n' +
    '  animation: drben-pulse 2s infinite !important;\n' +
    '}\n' +
    '.drben-fab:hover {\n' +
    '  transform: scale(1.08) !important;\n' +
    '  box-shadow: 0 6px 28px rgba(25,56,92,0.5), 0 0 0 4px rgba(222,192,120,0.2) !important;\n' +
    '}\n' +
    '.drben-fab img {\n' +
    '  width: 100% !important;\n' +
    '  height: 100% !important;\n' +
    '  object-fit: cover !important;\n' +
    '  border-radius: 50% !important;\n' +
    '}\n' +
    '.drben-fab-label {\n' +
    '  position: fixed !important;\n' +
    '  bottom: 96px !important;\n' +
    '  ' + position + ': 20px !important;\n' +
    '  z-index: 99998 !important;\n' +
    '  background: #19385c !important;\n' +
    '  color: #dec078 !important;\n' +
    '  padding: 8px 16px !important;\n' +
    '  border-radius: 8px !important;\n' +
    '  font-size: 13px !important;\n' +
    '  font-weight: 600 !important;\n' +
    '  font-family: "Cormorant Garamond", Georgia, serif !important;\n' +
    '  box-shadow: 0 4px 12px rgba(0,0,0,0.15) !important;\n' +
    '  white-space: nowrap !important;\n' +
    '  pointer-events: none !important;\n' +
    '  opacity: 0 !important;\n' +
    '  transform: translateY(8px) !important;\n' +
    '  transition: all 0.3s ease !important;\n' +
    '}\n' +
    '.drben-fab:hover + .drben-fab-label,\n' +
    '.drben-fab-label.drben-show {\n' +
    '  opacity: 1 !important;\n' +
    '  transform: translateY(0) !important;\n' +
    '}\n' +
    '\n' +
    '/* ── Chat Modal ── */\n' +
    '.drben-modal {\n' +
    '  position: fixed !important;\n' +
    '  bottom: 100px !important;\n' +
    '  ' + position + ': 24px !important;\n' +
    '  z-index: 99999 !important;\n' +
    '  width: 420px !important;\n' +
    '  height: 620px !important;\n' +
    '  max-width: calc(100vw - 32px) !important;\n' +
    '  max-height: calc(100vh - 120px) !important;\n' +
    '  border-radius: 16px !important;\n' +
    '  overflow: hidden !important;\n' +
    '  box-shadow: 0 12px 48px rgba(25,56,92,0.3), 0 0 0 1px rgba(222,192,120,0.2) !important;\n' +
    '  transform: scale(0.9) translateY(20px) !important;\n' +
    '  opacity: 0 !important;\n' +
    '  transition: all 0.3s cubic-bezier(0.34,1.56,0.64,1) !important;\n' +
    '  pointer-events: none !important;\n' +
    '  visibility: hidden !important;\n' +
    '}\n' +
    '.drben-modal.drben-open {\n' +
    '  transform: scale(1) translateY(0) !important;\n' +
    '  opacity: 1 !important;\n' +
    '  pointer-events: auto !important;\n' +
    '  visibility: visible !important;\n' +
    '}\n' +
    '.drben-modal iframe {\n' +
    '  width: 100% !important;\n' +
    '  height: 100% !important;\n' +
    '  border: none !important;\n' +
    '}\n' +
    '.drben-close {\n' +
    '  position: absolute !important;\n' +
    '  top: 8px !important;\n' +
    '  right: 8px !important;\n' +
    '  z-index: 100000 !important;\n' +
    '  width: 32px !important;\n' +
    '  height: 32px !important;\n' +
    '  border-radius: 50% !important;\n' +
    '  background: rgba(25,56,92,0.9) !important;\n' +
    '  border: 1px solid rgba(222,192,120,0.4) !important;\n' +
    '  color: #dec078 !important;\n' +
    '  font-size: 18px !important;\n' +
    '  cursor: pointer !important;\n' +
    '  display: flex !important;\n' +
    '  align-items: center !important;\n' +
    '  justify-content: center !important;\n' +
    '  transition: all 0.2s !important;\n' +
    '  line-height: 1 !important;\n' +
    '}\n' +
    '.drben-close:hover {\n' +
    '  background: #19385c !important;\n' +
    '  transform: scale(1.1) !important;\n' +
    '}\n' +
    '.drben-overlay {\n' +
    '  position: fixed !important;\n' +
    '  inset: 0 !important;\n' +
    '  z-index: 99998 !important;\n' +
    '  background: rgba(0,0,0,0.3) !important;\n' +
    '  opacity: 0 !important;\n' +
    '  transition: opacity 0.3s !important;\n' +
    '  pointer-events: none !important;\n' +
    '  visibility: hidden !important;\n' +
    '}\n' +
    '.drben-overlay.drben-open {\n' +
    '  opacity: 1 !important;\n' +
    '  pointer-events: auto !important;\n' +
    '  visibility: visible !important;\n' +
    '}\n' +
    '\n' +
    '/* ── Animations ── */\n' +
    '@keyframes drben-pulse {\n' +
    '  0% { box-shadow: 0 4px 20px rgba(25,56,92,0.4), 0 0 0 0 rgba(222,192,120,0.4); }\n' +
    '  70% { box-shadow: 0 4px 20px rgba(25,56,92,0.4), 0 0 0 10px rgba(222,192,120,0); }\n' +
    '  100% { box-shadow: 0 4px 20px rgba(25,56,92,0.4), 0 0 0 0 rgba(222,192,120,0); }\n' +
    '}\n' +
    '\n' +
    '/* ── Mobile Responsive ── */\n' +
    '@media (max-width: 480px) {\n' +
    '  .drben-modal {\n' +
    '    bottom: 0 !important; left: 0 !important; right: 0 !important;\n' +
    '    width: 100vw !important;\n' +
    '    height: 100vh !important;\n' +
    '    max-width: 100vw !important;\n' +
    '    max-height: 100vh !important;\n' +
    '    border-radius: 0 !important;\n' +
    '  }\n' +
    '  .drben-fab { bottom: 16px !important; ' + position + ': 16px !important; width: 56px !important; height: 56px !important; }\n' +
    '  .drben-fab-label { bottom: 80px !important; ' + position + ': 12px !important; }\n' +
    '}\n';
  document.head.appendChild(css);

  // ── State ───────────────────────────────────────────────
  var iframe = null;
  var isOpen = false;

  // ── Open / Close Chat ───────────────────────────────────
  function openChat() {
    if (!iframe) {
      iframe = document.createElement('iframe');
      iframe.src = embedUrl;
      iframe.setAttribute('allow', 'microphone');
      iframe.setAttribute('title', 'Dr. Ben - Assistente Jurídico Virtual');
      modal.appendChild(iframe);
    }
    modal.classList.add('drben-open');
    overlay.classList.add('drben-open');
    isOpen = true;
    fab.style.display = 'none';
    fabLabel.style.display = 'none';
  }

  function closeChat() {
    modal.classList.remove('drben-open');
    overlay.classList.remove('drben-open');
    isOpen = false;
    fab.style.display = 'flex';
    fabLabel.style.display = 'block';
  }

  // ── Helper: Create Dr. Ben nav link element ─────────────
  function createNavElement(extraClasses, isLink) {
    var a = document.createElement('a');
    if (isLink) {
      a.href = landingUrl;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
    }
    a.className = 'drben-nav-item' + (extraClasses ? ' ' + extraClasses : '');
    a.setAttribute('aria-label', 'Dr. Ben - Assistente Jurídico Virtual');
    a.setAttribute('title', 'Dr. Ben - Assistente Jurídico Virtual');

    var img = document.createElement('img');
    img.src = drBenPhoto;
    img.alt = 'Dr. Ben';
    img.className = 'drben-nav-avatar';

    var span = document.createElement('span');
    span.className = 'drben-nav-text';
    span.textContent = 'Dr. Ben';

    var badge = document.createElement('span');
    badge.className = 'drben-nav-badge';
    badge.textContent = 'IA';

    var underline = document.createElement('div');
    underline.className = 'drben-nav-underline';

    a.appendChild(img);
    a.appendChild(span);
    a.appendChild(badge);
    a.appendChild(underline);

    if (!isLink) {
      a.setAttribute('role', 'button');
      a.setAttribute('tabindex', '0');
      a.addEventListener('click', function(e) {
        e.preventDefault();
        openChat();
      });
      a.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          openChat();
        }
      });
    }

    return a;
  }

  // ── Find nav container (universal) ──────────────────────
  function findNavContainer() {
    // Strategy 1: UL-based menu (Hostinger version)
    var navUl = document.querySelector('ul.desktop1\\:flex');
    if (navUl) return { type: 'ul', el: navUl };

    // Strategy 2: DIV-based menu (Manus Space / www version)
    // Look for a div that contains direct <a> children with nav text
    var navKeywords = ['Início', 'Áreas de Atuação', 'Soluções Jurídicas', 'Sobre Nós', 'Blog', 'FAQ', 'Contato', 'Serviços', 'Perguntas Frequentes'];
    var allDivs = document.querySelectorAll('div');
    for (var i = 0; i < allDivs.length; i++) {
      var div = allDivs[i];
      var directLinks = div.querySelectorAll(':scope > a');
      if (directLinks.length >= 4) {
        var matchCount = 0;
        for (var j = 0; j < directLinks.length; j++) {
          var linkText = directLinks[j].textContent.trim();
          if (navKeywords.indexOf(linkText) !== -1) {
            matchCount++;
          }
        }
        if (matchCount >= 3) {
          return { type: 'div', el: div };
        }
      }
    }

    // Strategy 3: UL fallback - find any UL with nav-like links
    var allUls = document.querySelectorAll('ul');
    for (var k = 0; k < allUls.length; k++) {
      var links = allUls[k].querySelectorAll('a');
      var ulMatchCount = 0;
      for (var l = 0; l < links.length; l++) {
        var t = links[l].textContent.trim();
        if (navKeywords.indexOf(t) !== -1) {
          ulMatchCount++;
        }
      }
      if (ulMatchCount >= 3) {
        return { type: 'ul', el: allUls[k] };
      }
    }

    return null;
  }

  // ── Inject Nav Item (Desktop) ───────────────────────────
  function injectDesktopNav() {
    // Skip if already injected
    if (document.querySelector('.drben-nav-item')) return;

    var navInfo = findNavContainer();
    if (!navInfo) return;

    var container = navInfo.el;
    var containerType = navInfo.type;

    // Find the "Contato" or "FAQ" item to insert before
    var insertBeforeEl = null;
    var children = container.children;
    for (var k = 0; k < children.length; k++) {
      var el = children[k];
      var linkEl = (el.tagName === 'A') ? el : el.querySelector('a');
      if (linkEl) {
        var text = linkEl.textContent.trim();
        if (text === 'Contato') {
          insertBeforeEl = el;
          break;
        }
      }
    }

    if (containerType === 'div') {
      // DIV-based menu: insert a direct <a> element
      // Copy the class from existing links for consistent styling
      var existingLink = container.querySelector('a');
      var existingClass = existingLink ? existingLink.className : '';

      var navLink = createNavElement(existingClass, true);
      // Override some styles to match but keep gold accent
      navLink.style.cssText = '';

      if (insertBeforeEl) {
        container.insertBefore(navLink, insertBeforeEl);
      } else {
        container.appendChild(navLink);
      }
    } else {
      // UL-based menu: wrap in LI
      var li = document.createElement('li');
      li.className = 'transition group h-auto desktop1:w-auto text-center';

      var navLink2 = createNavElement('', true);
      li.appendChild(navLink2);

      if (insertBeforeEl) {
        container.insertBefore(li, insertBeforeEl);
      } else {
        container.appendChild(li);
      }
    }
  }

  // ── Inject Nav Item (Mobile/Footer) ─────────────────────
  function injectMobileNav() {
    // Find footer navigation lists
    var navKeywords = ['Início', 'Áreas de Atuação', 'Soluções Jurídicas', 'Sobre Nós', 'Blog', 'FAQ', 'Contato', 'Serviços', 'Perguntas Frequentes'];

    // Check all ULs for footer/mobile nav
    var allUls = document.querySelectorAll('ul');
    allUls.forEach(function(ul) {
      if (ul.querySelector('.drben-mobile-nav') || ul.querySelector('.drben-nav-item')) return;

      var links = ul.querySelectorAll('a');
      var matchCount = 0;
      for (var i = 0; i < links.length; i++) {
        if (navKeywords.indexOf(links[i].textContent.trim()) !== -1) {
          matchCount++;
        }
      }
      if (matchCount < 3) return;

      // This is a navigation list - add Dr. Ben
      var li = document.createElement('li');
      var a = document.createElement('a');
      a.href = landingUrl;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      a.className = 'drben-mobile-nav';

      // Copy class from existing links for consistency
      var existingLink = ul.querySelector('a');
      if (existingLink && existingLink.className) {
        a.className = existingLink.className + ' drben-mobile-nav';
      }

      var img = document.createElement('img');
      img.src = drBenPhoto;
      img.alt = 'Dr. Ben';
      img.className = 'drben-nav-avatar';

      var textSpan = document.createElement('span');
      textSpan.textContent = 'Dr. Ben';
      textSpan.className = 'drben-nav-text';

      var badge = document.createElement('span');
      badge.className = 'drben-nav-badge';
      badge.textContent = 'IA';

      a.appendChild(img);
      a.appendChild(textSpan);
      a.appendChild(badge);
      li.appendChild(a);
      ul.appendChild(li);
    });

    // Also check DIV-based footer navs
    var footerDivs = document.querySelectorAll('footer div, [class*="footer"] div');
    footerDivs.forEach(function(div) {
      if (div.querySelector('.drben-mobile-nav') || div.querySelector('.drben-nav-item')) return;

      var directLinks = div.querySelectorAll(':scope > a');
      if (directLinks.length < 3) return;

      var matchCount = 0;
      for (var i = 0; i < directLinks.length; i++) {
        if (navKeywords.indexOf(directLinks[i].textContent.trim()) !== -1) {
          matchCount++;
        }
      }
      if (matchCount < 3) return;

      // This is a footer nav div
      var a = document.createElement('a');
      a.href = landingUrl;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      a.className = 'drben-nav-item';

      // Copy class from existing links
      var existingLink = directLinks[0];
      if (existingLink && existingLink.className) {
        a.className = existingLink.className + ' drben-nav-item';
      }

      var img = document.createElement('img');
      img.src = drBenPhoto;
      img.alt = 'Dr. Ben';
      img.className = 'drben-nav-avatar';

      var textSpan = document.createElement('span');
      textSpan.textContent = 'Dr. Ben';
      textSpan.className = 'drben-nav-text';

      var badge = document.createElement('span');
      badge.className = 'drben-nav-badge';
      badge.textContent = 'IA';

      a.appendChild(img);
      a.appendChild(textSpan);
      a.appendChild(badge);
      div.appendChild(a);
    });

    // Also try to inject in mobile hamburger/sidebar menus
    var mobileMenus = document.querySelectorAll('[class*="mobile"], [class*="sidebar"], [class*="drawer"]');
    mobileMenus.forEach(function(menu) {
      if (menu.querySelector('.drben-mobile-nav') || menu.querySelector('.drben-nav-item')) return;

      var menuLinks = menu.querySelectorAll('a');
      var hasNav = false;
      for (var i = 0; i < menuLinks.length; i++) {
        if (navKeywords.indexOf(menuLinks[i].textContent.trim()) !== -1) {
          hasNav = true;
          break;
        }
      }
      if (!hasNav) return;

      var btn = document.createElement('a');
      btn.href = landingUrl;
      btn.target = '_blank';
      btn.rel = 'noopener noreferrer';
      btn.className = 'drben-mobile-nav';

      var img2 = document.createElement('img');
      img2.src = drBenPhoto;
      img2.alt = 'Dr. Ben';
      img2.className = 'drben-nav-avatar';

      var text2 = document.createElement('span');
      text2.textContent = 'Dr. Ben';
      text2.className = 'drben-nav-text';

      var badge2 = document.createElement('span');
      badge2.className = 'drben-nav-badge';
      badge2.textContent = 'IA';

      btn.appendChild(img2);
      btn.appendChild(text2);
      btn.appendChild(badge2);
      menu.appendChild(btn);
    });
  }

  // ── Create FAB ──────────────────────────────────────────
  var fab = document.createElement('div');
  fab.className = 'drben-fab';
  fab.setAttribute('aria-label', 'Abrir Dr. Ben - Assistente Jurídico');
  fab.setAttribute('role', 'button');
  fab.setAttribute('tabindex', '0');
  fab.innerHTML = '<img src="' + drBenPhoto + '" alt="Dr. Ben" />';
  document.body.appendChild(fab);

  var fabLabel = document.createElement('div');
  fabLabel.className = 'drben-fab-label';
  fabLabel.textContent = 'Fale com o Dr. Ben';
  document.body.appendChild(fabLabel);

  // Show label briefly on load
  setTimeout(function() {
    fabLabel.classList.add('drben-show');
    setTimeout(function() {
      fabLabel.classList.remove('drben-show');
    }, 4000);
  }, 2000);

  // ── Create Overlay ──────────────────────────────────────
  var overlay = document.createElement('div');
  overlay.className = 'drben-overlay';
  document.body.appendChild(overlay);

  // ── Create Modal ────────────────────────────────────────
  var modal = document.createElement('div');
  modal.className = 'drben-modal';
  modal.innerHTML = '<button class="drben-close" aria-label="Fechar">&times;</button>';
  document.body.appendChild(modal);

  // ── Event Listeners ─────────────────────────────────────
  fab.addEventListener('click', openChat);
  fab.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openChat(); }
  });
  modal.querySelector('.drben-close').addEventListener('click', closeChat);
  overlay.addEventListener('click', closeChat);
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && isOpen) closeChat();
  });

  // Listen for messages from iframe
  window.addEventListener('message', function(e) {
    if (e.data && e.data.type === 'drben:completed') {
      if (window.gtag) {
        window.gtag('event', 'drben_lead_qualified', {
          event_category: 'Dr. Ben',
          event_label: 'Lead Qualificado',
        });
      }
    }
  });

  // ── Initialize ──────────────────────────────────────────
  function init() {
    injectDesktopNav();
    injectMobileNav();
  }

  // Run on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Also observe for dynamic content (SPA navigation)
  var observer = new MutationObserver(function(mutations) {
    var shouldReinject = false;
    for (var i = 0; i < mutations.length; i++) {
      if (mutations[i].addedNodes.length > 0) {
        shouldReinject = true;
        break;
      }
    }
    if (shouldReinject && !document.querySelector('.drben-nav-item')) {
      // Debounce
      clearTimeout(observer._timeout);
      observer._timeout = setTimeout(function() {
        injectDesktopNav();
        injectMobileNav();
      }, 500);
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });

})();
